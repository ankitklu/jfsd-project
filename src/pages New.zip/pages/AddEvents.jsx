import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from 'react-router-dom'; // Import useNavigate

const AddEventForm = () => {
  const [event, setEvent] = useState({
    title: "",
    venue: "",
    eventDate: "",
    eventTime: "", // Add a field for time
    description: "",
    poster: "",
    credits: "",
  });
  const navigate = useNavigate(); // Initialize navigate

  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEvent({ ...event, [name]: value });
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      setEvent({ ...event, poster: reader.result });
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!event.title || !event.venue || !event.eventDate || !event.eventTime || !event.description || !event.credits) {
      setErrorMessage("All fields are required!");
      return;
    }
    setErrorMessage("");

    // Combine date and time into a single value if needed, or send them separately
    const eventDateTime = `${event.eventDate}T${event.eventTime}`;

    const eventData = { ...event, eventDateTime }; // Add the combined date and time

    axios
      .post("http://localhost:8080/api/events/create", eventData)
      .then((res) => {
        navigate('/adminDashboard'); // Redirect after success
        setEvent({
          title: "",
          venue: "",
          eventDate: "",
          eventTime: "", // Reset time field
          description: "",
          poster: "",
          credits: "",
        });
      })
      .catch(() => setErrorMessage("Failed to create event."));
  };

  return (
    <div className="flex justify-center items-start min-h-screen bg-gradient-to-r from-blue-400 via-indigo-500 to-purple-600 pt-12">
      <div className="bg-white bg-opacity-80 p-10 rounded-lg shadow-2xl max-w-3xl w-full backdrop-blur-md" style={{ marginTop: '100px' }}>
        <div className="text-center mb-8">
          <h2 className="text-2xl font-extrabold text-indigo-700 animate-bounce">
            Upload a New Event
          </h2>
          <p className="text-lg text-gray-700">Fill in the event details below</p>
        </div>

        {successMessage && (
          <div className="bg-green-100 text-green-800 p-4 mb-4 rounded">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-100 text-red-800 p-4 mb-4 rounded">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Event Title */}
          <div>
            <label className="block text-gray-800 font-semibold mb-1">Event Title</label>
            <input
              type="text"
              name="title"
              value={event.title}
              onChange={handleInputChange}
              className="w-full border-2 border-indigo-300 rounded-md p-4 focus:outline-none focus:ring-2 focus:ring-pink-500 transition-shadow shadow-sm hover:shadow-md"
              placeholder="Enter event title"
              required
            />
          </div>

          {/* Event Venue */}
          <div>
            <label className="block text-gray-800 font-semibold mb-1">Venue</label>
            <input
              type="text"
              name="venue"
              value={event.venue}
              onChange={handleInputChange}
              className="w-full border-2 border-indigo-300 rounded-md p-4 focus:outline-none focus:ring-2 focus:ring-pink-500 transition-shadow shadow-sm hover:shadow-md"
              placeholder="Enter event venue"
              required
            />
          </div>

          {/* Event Date */}
          <div>
            <label className="block text-gray-800 font-semibold mb-1">Event Date</label>
            <input
              type="date"
              name="eventDate"
              value={event.eventDate}
              onChange={handleInputChange}
              className="w-full border-2 border-indigo-300 rounded-md p-4 focus:outline-none focus:ring-2 focus:ring-pink-500 transition-shadow shadow-sm hover:shadow-md"
              required
            />
          </div>

          {/* Event Time */}
          <div>
            <label className="block text-gray-800 font-semibold mb-1">Event Time</label>
            <input
              type="time"
              name="eventTime"
              value={event.eventTime}
              onChange={handleInputChange}
              className="w-full border-2 border-indigo-300 rounded-md p-4 focus:outline-none focus:ring-2 focus:ring-pink-500 transition-shadow shadow-sm hover:shadow-md"
              required
            />
          </div>

          {/* Event Credits */}
          <div>
            <label className="block text-gray-800 font-semibold mb-1">Credits</label>
            <input
              type="number"
              name="credits"
              value={event.credits}
              onChange={handleInputChange}
              className="w-full border-2 border-indigo-300 rounded-md p-4 focus:outline-none focus:ring-2 focus:ring-pink-500 transition-shadow shadow-sm hover:shadow-md"
              placeholder="Enter event credits"
              required
            />
          </div>

          {/* Event Description */}
          <div>
            <label className="block text-gray-800 font-semibold mb-1">Description</label>
            <textarea
              name="description"
              value={event.description}
              onChange={handleInputChange}
              className="w-full border-2 border-indigo-300 rounded-md p-4 focus:outline-none focus:ring-2 focus:ring-pink-500 transition-shadow shadow-sm hover:shadow-md"
              placeholder="Enter event description"
              rows="4"
              required
            />
          </div>

          {/* Event Poster Upload */}
          <div>
            <label className="block text-gray-800 font-semibold mb-1">Event Poster</label>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="w-full border-2 border-indigo-300 rounded-md p-4 focus:outline-none focus:ring-2 focus:ring-pink-500 transition-shadow shadow-sm hover:shadow-md"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-gradient-to-br from-blue-400 via-indigo-500 to-purple-600 text-white py-4 rounded-lg shadow-md hover:shadow-lg transition-transform transform hover:scale-105"
          >
            Add Event
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddEventForm;
